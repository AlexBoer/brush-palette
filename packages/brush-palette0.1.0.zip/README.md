# brush-palette
makes it easy to change drawing settings.
